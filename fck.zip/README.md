on the root of the folder type 'nodemon server.js'
